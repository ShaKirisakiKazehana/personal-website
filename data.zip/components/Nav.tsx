// components/Nav.tsx
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const items = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/resume", label: "Resume" },
];

export default function Nav() {
  const pathname = usePathname();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-transparent">
      <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/" className="font-semibold">
          Jerry Xie
        </Link>

        <nav className="flex gap-2">
          {items.map((item) => {
            const active = pathname === item.href;
            return (
            <Link
            key={item.href}
            href={item.href}
            className={[
                "px-3 py-2 rounded-xl text-sm border border-white/40 transition",
                active
                ? "bg-white text-black"
                : "text-white hover:border-white",
            ].join(" ")}
            >
            {item.label}
            </Link>

            );
          })}
        </nav>
      </div>
    </header>
  );
}
