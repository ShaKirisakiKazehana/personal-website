export default function Home() {
  return (
    <section
      className="
        relative h-[100svh] w-full
        bg-black text-white
        overflow-hidden
      "
    >
      {/* Background Image */}
      <div
        className="
          absolute inset-0
          bg-[url('/landing.jpg')]
          bg-cover bg-center
        "
      />

      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black/60" />

      {/* Content */}
      <div
        className="
          relative z-10
          h-full
          flex items-center
        "
      >
        <div className="max-w-5xl mx-auto px-6">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
            Jerry Xie
          </h1>

          <p className="mt-4 text-lg md:text-xl text-neutral-200 max-w-xl">
            Computer Science Student · Aspiring Software Engineer
          </p>

          <div className="mt-8 flex gap-4">
            <a
              href="/resume"
              className="
                rounded-xl
                border border-white
                px-6 py-3
                text-sm font-medium
                hover:bg-white hover:text-black
                transition
              "
            >
              Resume
            </a>

            <a
              href="/about"
              className="
                rounded-xl
                border border-white/40
                px-6 py-3
                text-sm font-medium
                hover:border-white
                transition
              "
            >
              About
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
