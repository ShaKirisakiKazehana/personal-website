export default function About() {
    return (
        <div className="bg-white text-black">

        <h1 className="text-2xl font-semibold">About</h1>
        <p className="text-neutral-700 leading-relaxed">
          Write 5–10 lines about who you are, what you build, and what roles you’re looking for.
        </p>
  
        <ul className="list-disc pl-5 text-neutral-700 space-y-2">
          <li>Strong in full-stack fundamentals and shipping projects.</li>
          <li>Comfortable with React/Next.js, Node/Python, and SQL.</li>
          <li>Interested in building reliable, user-focused systems.</li>
        </ul>
      </div>
    );
  }
  