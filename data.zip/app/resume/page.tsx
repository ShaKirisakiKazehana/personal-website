export default function Resume() {
    return (
        <div className="bg-white text-black">

        <h1 className="text-2xl font-semibold">Resume</h1>
  
        <a
          className="inline-flex items-center rounded-xl border px-4 py-2 hover:bg-neutral-50 transition"
          href="/resume.pdf"
          target="_blank"
        >
          Open / Download Resume (PDF)
        </a>
  
        <p className="text-sm text-neutral-600">
          Tip: Put your latest resume at <code className="border px-1 rounded">public/resume.pdf</code>.
        </p>
      </div>
    );
  }
  