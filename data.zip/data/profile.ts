// data/profile.ts
export const profile = {
    name: "Jerry Xie",
    title: "Computer Science Student • Aspiring Software Engineer",
    location: "Philadelphia, PA",
    bio: "I build reliable, user-focused software. Interested in full-stack and systems work.",
    email: "your@email.com",
    github: "https://github.com/YOUR_USERNAME",
    linkedin: "https://www.linkedin.com/in/YOUR_PROFILE",
    resumeUrl: "/resume.pdf",
    skills: [
      "JavaScript/TypeScript",
      "React/Next.js",
      "Node.js",
      "Python",
      "SQL",
      "Git/GitHub",
    ],
  };
  