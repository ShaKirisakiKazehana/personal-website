// data/profile.ts
export const profile = {
  name: "Jerry Xie",
  mark: "jx.",
  titleLine1: "software engineer,",
  titleLine2: "builder,",
  titleLine3: "problem solver",
  location: "Philadelphia, PA",
  email: "your@email.com",
  github: "https://github.com/YOUR_USERNAME",
  linkedin: "https://www.linkedin.com/in/YOUR_PROFILE",
};
